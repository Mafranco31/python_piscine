This is my first package in python !

It is composed of :
	- a Progress Bar
	- a Logger 
